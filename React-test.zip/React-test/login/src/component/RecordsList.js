import React, { Component } from 'react'

export default class RecordsList extends Component {
    render() {
        return (
            <tr>
                <td>
                    {this.props.payload.id}
                </td>
                <td>
                    {this.props.payload.name}
                </td>
                <td>
                {this.props.payload.year}
                </td>
                <td>
                {this.props.payload.color}
                </td>
                <td>
                {this.props.payload.pantone_value}
                </td>
            </tr>
        )
    }
}
