 import React, { Component } from 'react'
 import axios from 'axios'
 import {Redirect} from 'react-router'
 export default class Login extends Component {
    constructor(props) {
        super(props)
            this.onChangeEmail=this.onChangeEmail.bind(this);
            this.onChangePassword=this.onChangePassword.bind(this);
            this.onSubmit=this.onSubmit.bind(this);

            this.state={
                email:'',
                password:'',
                redirect:false
            }
        }
        onChangeEmail(e){
            this.setState({
                email:e.target.value
            })
        }
        onChangePassword(e){
            this.setState({
                password:e.target.value
            })
        }
        onSubmit(e){
            e.preventDefault();
            const payload = {
                email:this.state.email,
                password:this.state.password
            }
            axios.post("https://reqres.in/api/login",payload)
            .then(res=>console.log(res.data))
            this.setState({redirect:true})
            // .catch(function(error){
            //     console.log(error);
            // })
        }
     render() {
         const {redirect} =this.state;
         if(redirect){
             return <Redirect to ='/dashboard'/>
         }
         return (
             <>
                 <h1>Login</h1>
                 <div className='card col-12 col-lg-4 login-card mt-2 hv-center'>
                 <div className='form_body'>
                     <form className='user_form' onSubmit={this.onSubmit}>
                        <div className='form-group'>
                            <label className='txtaln'>Email</label>
                            <input 
                                type='text'
                                className='form-control'
                                value={this.state.email}
                                onChange={this.onChangeEmail}
                            />
                        </div>
                        <div className='form-group'>
                            <label className='txtaln'>Password</label>
                            <input 
                                type='password'
                                className='form-control'
                                value={this.state.password}
                                onChange={this.onChangePassword}
                            />
                        </div>
                        <div className='form-btn'>
                            <input type='submit' value="Login User" className='butn' />
                        </div>
                     </form>
                 </div>
                 </div>
             </>
         )
     }
 }
 