import React, { Component } from 'react'
import axios from 'axios';
import RecordsList from './RecordsList'
export default class Dashboard extends Component {
    constructor(props) {
        super(props)
            this.state={user:[]};
        }
        componentDidMount(){
            axios.get('https://reqres.in/api/login')

            .then(response=>
                {
                console.log(response.data.data)
                this.setState({

                    user:response.data.data
                   
                })
                
            })
            .catch(function(error){
                    console.log(error)
                })
        }
userLists(){
    return this.state.user.map(function(object,i){
        return<RecordsList payload={object} key={i}/>
    })
}
    render() {
        return (
            <div>
                
                <table border='2'>
                    <thead>
                    <tr>
                        <th>Id</th>   
                        <th>Name</th>
                        <th>Year</th>
                        <th>Color</th>
                        <th>Pantone_value</th>
                    </tr>
                </thead>
                <tbody>
                    {
                     this.userLists()
                    }

                    
                </tbody>
                </table>
                
            </div>
        )
    }
}
