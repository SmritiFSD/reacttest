import React from 'react';
import './App.css';
import Login from './component/Login';
import Dashboard from './component/Dashboard';
import {BrowserRouter as Router,Route,Switch,Link} from 'react-router-dom'

function App() {
  return (
    <Router>
    <ul>
      <li>
      <Link to='/login'>Login</Link>
    </li>
    <li>
      <Link to='/dashboard'>Dashboard</Link>
    </li>
    </ul>
    
      <div className="App">
      <Switch>
        <Route exact path='/login' component={Login}/>
        <Route exact path='/dashboard' component={Dashboard} />
      </Switch>    
    </div>
    </Router>
  );
}

export default App;
